'use strict';
// Carga los datos iniciales (SKUs, ubicaciones, kardex y viajes) tomados de tu Excel.
// Uso: npm run seed   (se puede repetir: actualiza sin duplicar)
const fs = require('node:fs');
const path = require('node:path');
const { open, setDoc } = require('../lib/db');

const dataDir = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
fs.mkdirSync(dataDir, { recursive: true });
const db = open(path.join(dataDir, 'portal.db'));
const read = f => JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'seed', f), 'utf8'));
let n = 0;
db.exec('BEGIN');
const wms = read('wms.json');
for (const [k, list] of [['skus', wms.skus], ['ubic', wms.ubic], ['kardex', wms.kardex]]) {
  for (const o of list) { setDoc(db, `wms/${k}/items/${o.id}`, o); n++; }
}
for (const v of read('viajes.json')) { setDoc(db, `viajes/${v.id}`, v); n++; }
db.exec('COMMIT');
console.log(`${n} registros cargados en ${path.join(dataDir, 'portal.db')}`);
