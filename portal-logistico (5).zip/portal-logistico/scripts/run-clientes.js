'use strict';
// Levanta una instancia del portal por cada cliente de clientes/clientes.json, las reinicia si se caen
// y hace una copia diaria de cada una. Con SIGHUP relee la lista (para sumar un cliente nuevo sin cortar a los demás).
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const root = path.resolve(process.env.CLIENTES_DIR || path.join(__dirname, '..', 'clientes'));
const node = [process.execPath, '--disable-warning=ExperimentalWarning'];
const procs = new Map(); // slug -> { child, stop, tries }
const log = (slug, m) => console.log(`[${new Date().toISOString().slice(11, 19)}] ${slug}: ${m}`);

function leerEnv(file) {
  const e = {};
  for (const l of fs.readFileSync(file, 'utf8').split(/\r?\n/)) { const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)$/); if (m) e[m[1]] = m[2].replace(/^["']|["']$/g, ''); }
  return e;
}
const lista = () => { try { return JSON.parse(fs.readFileSync(path.join(root, 'clientes.json'), 'utf8')); } catch (_) { return []; } };

function arrancar(c) {
  const envFile = path.join(root, c.slug, '.env');
  if (!fs.existsSync(envFile)) { log(c.slug, 'falta ' + envFile); return; }
  const env = Object.assign({}, process.env, leerEnv(envFile)), st = procs.get(c.slug) || { tries: 0 };
  procs.set(c.slug, st); st.stop = false;
  const child = spawn(node[0], [node[1], path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  st.child = child; st.since = Date.now();
  const pipe = s => s.on('data', d => String(d).split('\n').filter(Boolean).forEach(l => log(c.slug, l)));
  pipe(child.stdout); pipe(child.stderr);
  child.on('exit', code => {
    if (st.stop) return;
    st.tries = Date.now() - st.since > 60e3 ? 1 : st.tries + 1;
    const wait = Math.min(30e3, 1000 * 2 ** st.tries);
    log(c.slug, `se detuvo (código ${code}); reintento en ${Math.round(wait / 1000)} s`);
    setTimeout(() => { if (!st.stop && procs.get(c.slug) === st) arrancar(c); }, wait);
  });
}
function copia(c) {
  const envFile = path.join(root, c.slug, '.env'); if (!fs.existsSync(envFile)) return;
  const p = spawn(node[0], [node[1], path.join(__dirname, 'backup.js')], { env: Object.assign({}, process.env, leerEnv(envFile)), stdio: 'ignore' });
  p.on('exit', code => log(c.slug, code === 0 ? 'copia diaria hecha' : 'LA COPIA FALLÓ (código ' + code + ')'));
}
function sincronizar() {
  const l = lista(), slugs = new Set(l.map(c => c.slug));
  for (const c of l) if (!procs.has(c.slug) || procs.get(c.slug).stop) { log(c.slug, 'iniciando'); arrancar(c); }
  for (const [slug, st] of procs) if (!slugs.has(slug)) { st.stop = true; st.child.kill(); procs.delete(slug); log(slug, 'quitado'); }
}
function salir() { for (const st of procs.values()) { st.stop = true; st.child.kill(); } setTimeout(() => process.exit(0), 300); }

if (require.main === module) {
  sincronizar();
  const copias = () => lista().forEach(copia);
  setTimeout(copias, 60e3).unref(); setInterval(copias, 24 * 3600e3).unref();
  process.on('SIGHUP', sincronizar); process.on('SIGINT', salir); process.on('SIGTERM', salir);
  log('supervisor', lista().length + ' clientes. SIGHUP para releer la lista.');
}
module.exports = { sincronizar };
