# Caso de ahorro — cómo calcular el retorno

> **Los números de abajo son un EJEMPLO inventado para mostrar la cuenta.** Reemplazalos por los de la empresa que visitás (se miden en la semana 1 del piloto).

## Datos de partida (ejemplo)
| Dato | Valor del ejemplo |
|---|---|
| Entregas por mes | 600 |
| Entregas que se reclaman por "no recibí" o faltante | 3% = 18 |
| Costo promedio de resolver un reclamo (horas, reenvío, nota de crédito) | $ 45.000 |
| Entregas fallidas por mes (cliente ausente, dirección mala) | 6% = 36 |
| Costo de reintentar una entrega | $ 18.000 |
| Horas por semana armando hojas de ruta y planillas | 10 h × $ 9.000 = $ 90.000/sem |

## Dónde aparece el ahorro
| Mejora esperada (supuesto) | Cuenta | Ahorro mensual |
|---|---|---|
| Reclamos: la prueba de entrega los reduce a la mitad | 9 reclamos × $ 45.000 | $ 405.000 |
| Fallidas: aviso al cliente y ventanas reducen un tercio | 12 entregas × $ 18.000 | $ 216.000 |
| Hojas de ruta y planillas: se ahorra el 40% | 4 sem × $ 90.000 × 40% | $ 144.000 |
| **Total (ejemplo)** | | **$ 765.000** |

Si el servicio cuesta [$ 250.000] por mes, el ejemplo da un retorno de **~3 veces** el costo. Con otros datos puede ser mucho menos: por eso el piloto mide antes de prometer.

## Cómo medirlo de verdad
1. Semana 1: contar reclamos, fallidas y horas con los datos del propio cliente (el portal ya calcula OTIF y causas).
2. Elegir **un solo** número de éxito para el piloto (por ejemplo, reclamos por mes).
3. Comparar al final del piloto con la misma cuenta y mostrarla con los números reales, aunque sean modestos.

## Cuidado al presentarlo
- Aclarar qué es supuesto y qué es medido.
- No prometer porcentajes que no medís.
