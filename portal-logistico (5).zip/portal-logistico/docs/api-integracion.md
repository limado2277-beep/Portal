# API de integración (ERP, planillas, BI)

Autenticación de servidor a servidor con el encabezado `X-API-Key` (variable `INTEGRATION_KEY`, 24 caracteres o más). No la pongas en una página web ni en un teléfono. Todo se hace por HTTPS.

## Cargar o actualizar entregas — `POST /api/integracion/entregas`
Hasta 500 por envío. Crea o actualiza por `guia` (sin distinguir mayúsculas).

```
curl -X POST https://TU-DOMINIO/api/integracion/entregas \
  -H "X-API-Key: TU_CLAVE" -H "Content-Type: application/json" \
  -d '{"entregas":[{"guia":"G-9001","cliente":"Ferretería Del Plata","chofer":"Marcos Peralta",
       "fecha":"2026-12-01","desde":"09:00","hasta":"12:00","direccion":"Av. Mitre 1890, Wilde",
       "bultos":6,"pesoKg":420,"lat":-34.70,"lng":-58.32}]}'
```
Campos obligatorios: `guia`, `cliente` (o `clienteId`), `fecha` (AAAA-MM-DD), `direccion`. Opcionales: `chofer`/`choferId`, `desde`/`hasta` (HH:MM, por defecto 08:00–18:00), `lat`/`lng`, `bultos`, `pesoKg`, `remito`, `factura`, `importe`, `vence`.
El cliente y el chofer **deben existir** en el portal. Respuesta: `{"creadas":n,"actualizadas":n,"errores":[{"fila":1,"guia":"…","error":"…"}]}`. Las filas con error no frenan al resto.

## Consultar estados — `GET /api/integracion/entregas?desde=AAAA-MM-DD`
Devuelve estado, hora de entrega y datos de la prueba de entrega (receptor, si estuvo completa, distancia a la dirección).

## Consultar stock — `GET /api/integracion/entregas?stock=1`
Suma el kardex por SKU, ubicación y lote. Sirve para conciliar contra el ERP.

## Avisos salientes (webhook)
Con `WEBHOOK_URL` y `WEBHOOK_SECRET` (16 caracteres o más) el portal hace un `POST` por cada **cambio de estado** de una entrega:
```
{"evento":"entrega.estado","ts":"2026-12-01T12:03:00.000Z","data":{"guia":"G-9001","cliente":"…","estado":"entregada","fecha":"2026-12-01","pod":{"receptor":"…","completa":true}}}
```
Encabezado `X-Signature: sha256=<HMAC-SHA256 del cuerpo exacto con WEBHOOK_SECRET>`. **Verificá la firma antes de procesar** y comparala en tiempo constante. Si tu sistema no responde 2xx, se reintenta a 1 y a 5 minutos y después queda registrado como fallido en la auditoría (no hay cola persistente: si el portal se reinicia en medio de los reintentos, ese aviso se pierde; conciliá con el GET).

## Quién construye y mantiene la conexión
Esta API es el contrato. El conector con SAP, Tango o Bejerman (un script que lee de la base del ERP y llama a este endpoint) **no está incluido**: se presupuesta aparte y se prueba con tus datos. Alcance, responsable y costo de mantenimiento van por escrito antes de empezar.
