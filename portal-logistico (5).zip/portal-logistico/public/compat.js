// Capa de acceso a datos: le da a la aplicación la misma interfaz de base de datos,
// usuarios y archivos, pero apoyada en la API de este servidor.
// Incluye modo sin conexión: lo último leído queda guardado en el aparato y los cambios
// hechos sin señal se guardan en una cola que se envía sola cuando vuelve la conexión.
(function () {
  'use strict';
  var POLL = 5000, bus = [];
  var QK = 'portal.cola', CK = 'portal.cache';
  var st = window.PORTAL_STATUS = { offline: false, pending: 0, dropped: 0, conflicts: 0, lastSync: 0, lastError: '', lost: [], notes: [] };
  var LK = 'portal.perdidos', NK = 'portal.avisos';

  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (_) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (_) { return false; } }
  var queue = lsGet(QK, []), cache = lsGet(CK, {}), uploads = [];
  st.lost = lsGet(LK, []); st.dropped = st.lost.length; st.notes = lsGet(NK, []); st.conflicts = st.notes.length;
  st.pending = queue.length;
  // IndexedDB: la cola completa y los archivos pendientes (localStorage tiene un tope de ~5 MB y una firma o foto lo llena).
  var idb = null, idbOk = typeof indexedDB !== 'undefined';
  function idbOpen() {
    if (idb) return Promise.resolve(idb);
    return new Promise(function (res, rej) {
      try { var r = indexedDB.open('portal-offline', 1); r.onupgradeneeded = function () { r.result.createObjectStore('kv'); r.result.createObjectStore('blobs'); }; r.onsuccess = function () { idb = r.result; res(idb); }; r.onerror = function () { rej(r.error); }; } catch (e) { rej(e); }
    });
  }
  function idbDo(store, mode, fn) { return idbOpen().then(function (d) { return new Promise(function (res, rej) { var tx = d.transaction(store, mode), rq = fn(tx.objectStore(store)); tx.oncomplete = function () { res(rq && rq.result); }; tx.onerror = tx.onabort = function () { rej(tx.error); }; }); }); }
  function persistQueue() {
    var snap = JSON.parse(JSON.stringify({ queue: queue, uploads: uploads }));
    if (idbOk) idbDo('kv', 'readwrite', function (o) { return o.put(snap, 'state'); }).catch(function () { idbOk = false; lsSet(QK, queue); });
    else lsSet(QK, queue);
    try { if (idbOk) localStorage.removeItem(QK); } catch (_) {}
  }
  var ready = !idbOk ? Promise.resolve() : idbDo('kv', 'readonly', function (o) { return o.get('state'); }).then(function (v) {
    if (v) {
      var mem = queue; queue = (v.queue || []).filter(function (q) { return !mem.some(function (m) { return m.path === q.path; }); }).concat(mem); uploads = v.uploads || [];
      st.pending = queue.length; changed();
    } else if (queue.length) persistQueue();
  }).catch(function () { idbOk = false; });
  function changed() { if (typeof window.__render === 'function') { try { window.__render(); } catch (_) {} } }
  function saveQueue() { st.pending = queue.length + uploads.length; persistQueue(); }
  function saveCache() { if (!lsSet(CK, cache)) { cache = {}; lsSet(CK, cache); } }

  function isNet(e) { return e && e.offline; }
  function rawFetch(url, opt) {
    return fetch(url, opt).catch(function () { var e = new Error('Sin conexión'); e.offline = true; throw e; });
  }
  function api(url, opt) {
    opt = opt || {};
    var o = { method: opt.method || 'GET', credentials: 'same-origin', headers: {} };
    if (opt.body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opt.body); }
    return rawFetch(url, o).then(function (r) {
      if (r.status === 401) { clearLocal(); location.reload(); throw { code: 401 }; }
      if (!r.ok) return r.json().catch(function () { return {}; }).then(function (j) { var e = new Error(j.error || ('http ' + r.status)); e.code = r.status; throw e; });
      return r.status === 204 ? null : r.json();
    });
  }
  function clearLocal() { queue = []; uploads = []; cache = {}; try { localStorage.removeItem(QK); localStorage.removeItem(CK); localStorage.removeItem(LK); localStorage.removeItem(NK); } catch (_) {} st.pending = 0; st.lost = []; st.notes = []; st.dropped = 0; st.conflicts = 0; if (idbOk) { idbDo('kv', 'readwrite', function (o) { return o.clear(); }).catch(function () {}); idbDo('blobs', 'readwrite', function (o) { return o.clear(); }).catch(function () {}); } }
  window.portalClearLocal = clearLocal;

  // Lectura con respaldo local: si no hay señal, devuelve lo último que se vio.
  function read(url) {
    return api(url).then(function (res) {
      if (st.offline) { st.offline = false; changed(); }
      if (!Array.isArray(res) || res.length <= 300) { cache[url] = res; saveCache(); }
      return res;
    }, function (e) {
      if (isNet(e)) {
        if (!st.offline) { st.offline = true; changed(); }
        if (cache[url] !== undefined) return cache[url];
      }
      throw e;
    });
  }
  // Superpone los cambios todavía no enviados sobre lo leído, para que la pantalla los muestre.
  function overlayDoc(path, res) {
    var r = res;
    queue.forEach(function (q) { if (q.path === path) r = q.method === 'DELETE' ? { exists: false } : { exists: true, data: q.body }; });
    return r;
  }
  function overlayCol(coll, rows) {
    var out = rows.slice();
    queue.forEach(function (q) {
      var i = q.path.lastIndexOf('/'); if (q.path.slice(0, i) !== coll) return;
      var id = q.path.slice(i + 1), k = out.findIndex(function (x) { return x.id === id; });
      if (q.method === 'DELETE') { if (k >= 0) out.splice(k, 1); }
      else if (k >= 0) out[k] = { id: id, data: q.body }; else if (q.inCol !== false) out.push({ id: id, data: q.body });
    });
    return out;
  }

  function rid() {
    var a = new Uint8Array(10); crypto.getRandomValues(a);
    return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  // Consulta periódica: avisa solo cuando algo cambió.
  function watch(fetchFn, cb, err) {
    var last = null, dead = false, busy = false;
    function tick() {
      if (dead || busy || (document.hidden && last !== null)) return;
      busy = true;
      fetchFn().then(function (res) {
        busy = false; var s = (res && res.sig !== undefined && res.mk) ? res.sig : JSON.stringify(res);
        if (s !== last) { last = s; cb(res && res.mk ? res.mk() : res); }
      }).catch(function (e) { busy = false; if (err && last === null) { last = 'err'; err(e); } });
    }
    var h = { run: tick }; bus.push(h); tick();
    var iv = setInterval(tick, POLL);
    return function () { dead = true; clearInterval(iv); var i = bus.indexOf(h); if (i >= 0) bus.splice(i, 1); };
  }
  function refreshAll() { bus.slice().forEach(function (h) { h.run(); }); }

  // Escritura: si no hay señal, queda en cola y se envía más tarde.
  // Lo último que este aparato vio de un documento: sirve de punto de partida para unir cambios al reconectar.
  function knownDoc(path) {
    var r = cache['/api/doc?path=' + encodeURIComponent(path)];
    if (r && r.exists) return r.data;
    var i = path.lastIndexOf('/'), coll = path.slice(0, i), id = path.slice(i + 1), found;
    Object.keys(cache).forEach(function (u) {
      if (found || u.indexOf('/api/col?path=' + encodeURIComponent(coll)) !== 0) return;
      var rows = cache[u]; if (Array.isArray(rows)) { var x = rows.find(function (y) { return y.id === id; }); if (x) found = x.data; }
    });
    return found;
  }
  function write(method, path, body) {
    var url = '/api/doc?path=' + encodeURIComponent(path);
    return api(url, { method: method, body: body }).then(function () { refreshAll(); }, function (e) {
      if (!(isNet(e) || e.code === 429 || e.code >= 500)) throw e;
      if (!isNet(e)) st.lastError = e.message || 'error del servidor';
      var prev = queue.filter(function (q) { return q.path === path; })[0];
      var base = prev ? prev.base : knownDoc(path);
      queue = queue.filter(function (q) { return q.path !== path; });
      queue.push({ method: method, path: path, body: body === undefined ? null : JSON.parse(JSON.stringify(body)), base: base === undefined ? null : JSON.parse(JSON.stringify(base)), ts: Date.now(), tries: 0 });
      saveQueue(); if (isNet(e) && !st.offline) st.offline = true; changed(); refreshAll();
    });
  }
  // Une lo cambiado en este aparato con lo que hay hoy en el servidor: gana lo que se tocó acá,
  // se conserva lo que otros cambiaron en otros campos y las listas de historial se suman.
  var APPEND = { historial: 1, observaciones: 1 };
  var same = function (a, b) { return JSON.stringify(a) === JSON.stringify(b); };
  function mergeDoc(base, mine, theirs, note) {
    if (!base || !theirs) return mine;
    var out = {}, keys = {}; [mine, theirs, base].forEach(function (o) { Object.keys(o).forEach(function (k) { keys[k] = 1; }); });
    Object.keys(keys).forEach(function (k) {
      var m = mine[k], t = theirs[k], b = base[k];
      if (same(m, b)) { if (t !== undefined) out[k] = t; return; }              // no lo toqué: queda lo del servidor
      if (APPEND[k] && Array.isArray(m) && Array.isArray(t)) { var seen = {}; out[k] = t.concat(m).filter(function (x) { var j = JSON.stringify(x); if (seen[j]) return false; seen[j] = 1; return true; }); return; }
      if (!same(t, b) && !same(t, m)) note.push(k);                                // los dos tocamos el mismo campo
      if (m !== undefined) out[k] = m;
    });
    return out;
  }
  var flushing = false, backoff = 0, nextTry = 0;
  var retryable = function (e) { return isNet(e) || e.code === 429 || e.code >= 500; };
  function lose(q, e, what) {
    st.lost.push({ path: q.path || what, method: q.method || 'POST', msg: (e && e.message) || 'rechazado', code: e && e.code, ts: Date.now() }); st.lost = st.lost.slice(-30);
    st.dropped = st.lost.length; lsSet(LK, st.lost);
  }
  function note(msg) { st.notes.push({ msg: msg, ts: Date.now() }); st.notes = st.notes.slice(-30); st.conflicts = st.notes.length; lsSet(NK, st.notes); }
  function doneSync() { flushing = false; backoff = 0; st.offline = false; st.lastSync = Date.now(); st.lastError = ''; changed(); refreshAll(); }
  function fail(e) { flushing = false; st.lastError = (e && e.message) || 'error'; backoff = Math.min(60000, (backoff || 2000) * 2); nextTry = Date.now() + backoff; changed(); }
  function subirPendientes() {
    if (!uploads.length) return Promise.resolve();
    var u = uploads[0];
    return idbDo('blobs', 'readonly', function (o) { return o.get(u.id); }).then(function (file) {
      if (!file) { uploads.shift(); saveQueue(); return subirPendientes(); }
      return rawFetch('/api/upload', { method: 'POST', credentials: 'same-origin', headers: { 'X-Filename': encodeURIComponent(u.name), 'Content-Type': u.type || 'application/octet-stream' }, body: file }).then(function (r) {
        if (r.status === 401) { clearLocal(); location.reload(); throw { code: 401 }; }
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) { var e = new Error(j.error || ('http ' + r.status)); e.code = r.status; throw e; }
          var from = u.id, to = j.url;
          queue.forEach(function (q) { if (q.body) q.body = JSON.parse(JSON.stringify(q.body).split(from).join(to)); });
          uploads.shift(); idbDo('blobs', 'readwrite', function (o) { return o.delete(from); }).catch(function () {}); saveQueue(); return subirPendientes();
        });
      });
    }).catch(function (e) {
      if (e && !retryable(e)) { lose({ path: 'archivo ' + u.name, method: 'POST' }, e); uploads.shift(); idbDo('blobs', 'readwrite', function (o) { return o.delete(u.id); }).catch(function () {}); saveQueue(); return subirPendientes(); }
      throw e;
    });
  }
  function flush(force) {
    if (force === true) { nextTry = 0; }
    if (flushing || (!queue.length && !uploads.length) || Date.now() < nextTry) return Promise.resolve();
    flushing = true;
    var step = function () {
      if (!queue.length) { saveQueue(); doneSync(); return; }
      var q = queue[0], url = '/api/doc?path=' + encodeURIComponent(q.path);
      var send = q.method === 'DELETE' ? Promise.resolve(null) : (q.base ? api(url).catch(function (e) { if (e && e.code === 404) return { exists: false }; throw e; }) : Promise.resolve(null));
      send.then(function (cur) {
        var body = q.body;
        if (q.method !== 'DELETE' && cur && cur.exists && q.base) { var cf = []; body = mergeDoc(q.base, q.body, cur.data, cf); if (cf.length) note('En ' + q.path + ' se pisó lo que otra persona cambió en: ' + cf.join(', ') + '.'); }
        return api(url, { method: q.method, body: q.method === 'DELETE' ? undefined : body });
      }).then(function () { queue.shift(); saveQueue(); step(); }, function (e) {
        if (retryable(e)) { q.tries = (q.tries || 0) + 1; if (isNet(e) || q.tries < 20) { saveQueue(); return fail(e); } }
        // El servidor rechazó el cambio (por ejemplo, ya no tiene permiso): se guarda el aviso y no se traba la cola.
        lose(q, e); queue.shift(); saveQueue(); step();
      });
    };
    ready.then(function () { return subirPendientes(); }).then(step, function (e) { fail(e); });
    return Promise.resolve();
  }
  window.portalRetry = function () { return flush(true); };
  window.portalClearLost = function () { st.lost = []; st.dropped = 0; st.notes = []; st.conflicts = 0; lsSet(LK, []); lsSet(NK, []); changed(); };
  window.addEventListener('online', function () { flush(true); });
  setInterval(flush, 15000);
  setTimeout(flush, 1500);

  function docSnap(path) { return function (r) { return { id: path.split('/').pop(), exists: !!r.exists, data: function () { return r.data; } }; }; }
  function colSnap(rows) { return { docs: rows.map(function (r) { return { id: r.id, exists: true, data: function () { return r.data; } }; }), size: rows.length, empty: !rows.length }; }

  // Sin señal y sin copia de ese documento: se usa lo último que se vio dentro de alguna lista.
  function readDoc(q, path) {
    return read(q).catch(function (e) { var k = isNet(e) && knownDoc(path); if (k) return { exists: true, data: k }; throw e; });
  }
  function docRef(path) {
    var q = '/api/doc?path=' + encodeURIComponent(path);
    return {
      id: path.split('/').pop(), path: path,
      get: function () { return readDoc(q, path).then(function (r) { return docSnap(path)(overlayDoc(path, r)); }); },
      set: function (d) { return write('PUT', path, d); },
      delete: function () { return write('DELETE', path); },
      onSnapshot: function (cb, err) { return watch(function () { return readDoc(q, path).then(function (r) { return overlayDoc(path, r); }); }, function (r) { cb(docSnap(path)(r)); }, err); },
      collection: function (n) { return colRef(path + '/' + n); }
    };
  }
  function colRef(path, filters, ord, lim) {
    filters = filters || [];
    var url = function () {
      return '/api/col?path=' + encodeURIComponent(path) + (filters.length ? '&where=' + encodeURIComponent(JSON.stringify(filters)) : '') +
        (ord ? '&order=' + encodeURIComponent(ord[0] + ':' + ord[1]) : '') + (lim ? '&limit=' + lim : '');
    };
    var get = function (x, f) { return String(f).split('.').reduce(function (a, k) { return a == null ? undefined : a[k]; }, x); };
    var finish = function (rows) {
      rows = overlayCol(path, rows);
      if (ord) { var dir = ord[1] === 'desc' ? -1 : 1; rows.sort(function (a, b) { var x = get(a.data, ord[0]), y = get(b.data, ord[0]); return x === y ? 0 : (x == null ? 1 : y == null ? -1 : (x < y ? -dir : dir)); }); }
      return lim ? rows.slice(0, lim) : rows;
    };
    return {
      where: function (f, op, v) { return colRef(path, filters.concat([[f, op, v]]), ord, lim); },
      orderBy: function (f, dir) { return colRef(path, filters, [f, dir === 'desc' ? 'desc' : 'asc'], lim); },
      limit: function (n) { return colRef(path, filters, ord, n); },
      get: function () { return read(url()).then(function (rows) { return colSnap(finish(rows)); }); },
      onSnapshot: function (cb, err) {
        if (!filters.length && !ord && !lim && path.indexOf('wms/') === 0) {
          return watch(function () { return deltaFetch(path).then(function (r) { return { sig: r.sig, mk: function () { return finish(r.mk()); } }; }); }, function (rows) { cb(colSnap(rows)); }, err);
        }
        return watch(function () { return read(url()).then(finish); }, function (rows) { cb(colSnap(rows)); }, err);
      },
      doc: function (id) { return docRef(path + '/' + (id || rid())); }
    };
  }
  // Colecciones grandes del depósito: se baja todo una vez y después solo los cambios (cada consulta periódica pesa unos pocos bytes).
  var colMem = {};
  function queueSig() { return queue.map(function (q) { return q.path + q.ts; }).join(','); }
  function deltaFetch(path) {
    var m = colMem[path] || (colMem[path] = { map: {}, cursor: '', v: 0, loaded: false, saveT: 0 });
    function rebuild(r) { m.map = {}; r.rows.forEach(function (x) { m.map[x.id] = { id: x.id, version: x.version, data: x.data }; }); m.cursor = r.cursor || ''; m.v++; m.loaded = true; }
    function persist() {
      if (!idbOk || m.saveT) return;
      m.saveT = setTimeout(function () { m.saveT = 0; var rows = Object.keys(m.map).map(function (k) { return m.map[k]; }); idbDo('kv', 'readwrite', function (o) { return o.put({ rows: rows, cursor: m.cursor }, 'col:' + path); }).catch(function () {}); }, 2000);
    }
    function result() { return { sig: m.v + '|' + queueSig(), mk: function () { return Object.keys(m.map).sort().map(function (k) { return { id: k, data: m.map[k].data }; }); } }; }
    var base = '/api/col/delta?path=' + encodeURIComponent(path);
    return api(base + (m.loaded && m.cursor ? '&since=' + encodeURIComponent(m.cursor) : '')).then(function (r) {
      if (st.offline) { st.offline = false; changed(); }
      if (!m.loaded || !m.cursor) { rebuild(r); persist(); return result(); }
      var ch = false;
      r.rows.forEach(function (x) { var o = m.map[x.id]; if (!o || o.version !== x.version) { m.map[x.id] = { id: x.id, version: x.version, data: x.data }; ch = true; } });
      if (r.cursor) m.cursor = r.cursor;
      if (Object.keys(m.map).length !== r.count) return api(base).then(function (f) { rebuild(f); persist(); return result(); });
      if (ch) { m.v++; persist(); }
      return result();
    }, function (e) {
      if (!isNet(e)) throw e;
      if (!st.offline) { st.offline = true; changed(); }
      if (m.loaded) return result();
      return idbDo('kv', 'readonly', function (o) { return o.get('col:' + path); }).then(function (v) {
        if (!v) throw e;
        m.map = {}; v.rows.forEach(function (x) { m.map[x.id] = x; }); m.cursor = ''; m.loaded = true; m.v++; return result();
      }, function () { throw e; });
    });
  }
  var db = { doc: docRef, collection: function (p) { return colRef(p); } };

  var user = {
    me: function () { return read('/api/me'); },
    id: function () { return read('/api/me').then(function (m) { return m.id; }); },
    profiles: function (ids) { return read('/api/profiles?ids=' + encodeURIComponent((ids || []).join(','))); },
    search: function () { return Promise.resolve([]); }
  };
  var assets = {
    upload: function (file) {
      return rawFetch('/api/upload', { method: 'POST', credentials: 'same-origin', headers: { 'X-Filename': encodeURIComponent(file.name), 'Content-Type': file.type || 'application/octet-stream' }, body: file })
        .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || 'No se pudo subir'); return j; }); }, function () {
          // Sin señal: el archivo queda guardado en el aparato y se sube solo al volver; mientras tanto el documento lleva una referencia que se reemplaza al enviarlo.
          if (!idbOk || !file.size || file.size > 15 * 1024 * 1024) throw new Error('Sin conexión: el archivo no se puede subir ahora. Probá de nuevo cuando vuelva la señal.');
          var id = 'pendiente:' + rid();
          return idbDo('blobs', 'readwrite', function (o) { return o.put(file, id); }).then(function () {
            uploads.push({ id: id, name: file.name || 'archivo', type: file.type || 'application/octet-stream', ts: Date.now() }); saveQueue(); if (!st.offline) st.offline = true; changed();
            return { id: id, url: id, sizeBytes: file.size, contentType: file.type, pending: true };
          }, function () { throw new Error('Sin conexión: no se pudo guardar el archivo en el aparato.'); });
        });
    }
  };

  window.claude = { use: function (n) { return Promise.resolve(n === 'db' ? db : n === 'user' ? user : n === 'assets' ? assets : null); } };
})();
