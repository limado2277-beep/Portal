// Arranque: nombre de la empresa, pantalla de ingreso y carga de la aplicación.
(function () {
  'use strict';
  function load(src) { var s = document.createElement('script'); s.src = src; document.body.appendChild(s); }

  function showLogin(cfg) {
    var app = document.getElementById('app');
    app.textContent = '';
    var box = document.createElement('form');
    box.className = 'login'; box.setAttribute('autocomplete', 'on');
    var h = document.createElement('h1'); h.textContent = cfg.name; box.appendChild(h);
    var p = document.createElement('p'); p.className = 'muted'; p.style.margin = '0'; p.textContent = 'Ingresá con tu correo y contraseña.'; box.appendChild(p);
    function field(label, type, name, ac) {
      var l = document.createElement('label'); l.textContent = label;
      var i = document.createElement('input'); i.type = type; i.name = name; i.required = true; i.autocomplete = ac; l.appendChild(i); box.appendChild(l); return i;
    }
    var mail = field('Correo', 'email', 'email', 'username');
    var pass = field('Contraseña', 'password', 'password', 'current-password');
    var codeL = document.createElement('label'); codeL.textContent = 'Código de verificación (6 dígitos)'; codeL.hidden = true;
    var code = document.createElement('input'); code.type = 'text'; code.inputMode = 'numeric'; code.autocomplete = 'one-time-code'; code.maxLength = 6; codeL.appendChild(code); box.appendChild(codeL);
    var err = document.createElement('div'); err.className = 'err'; err.setAttribute('role', 'alert'); box.appendChild(err);
    var b = document.createElement('button'); b.className = 'btn pri'; b.type = 'submit'; b.textContent = 'Ingresar'; box.appendChild(b);
    var fg = document.createElement('a'); fg.href = '#'; fg.textContent = 'Olvidé mi contraseña'; fg.className = 'small';
    fg.addEventListener('click', function (ev) {
      ev.preventDefault(); err.textContent = '';
      if (!mail.value) { err.textContent = 'Escribí tu correo arriba y tocá de nuevo.'; mail.focus(); return; }
      fetch('/api/forgot', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: mail.value }) })
        .then(function (r) { err.style.color = 'var(--ok)'; err.textContent = r.ok ? 'Si el correo existe, te enviamos un enlace para elegir una contraseña nueva.' : 'No se pudo enviar. Probá más tarde.'; });
    });
    box.appendChild(fg);
    box.addEventListener('submit', function (ev) {
      ev.preventDefault(); err.textContent = ''; err.style.color = ''; b.disabled = true;
      fetch('/api/login', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: mail.value, password: pass.value, code: code.value }) })
        .then(function (r) { return r.json().then(function (j) { if (!r.ok) { if (j.needCode) { codeL.hidden = false; code.required = true; code.focus(); } throw new Error(j.error || 'No se pudo ingresar'); } location.reload(); }); })
        .catch(function (e) { err.textContent = e.message; b.disabled = false; });
    });
    app.appendChild(box); mail.focus();
  }

  // Sin conexión: la copia del navegador (service worker) permite abrir la aplicación con lo último que se vio.
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(function () {});
  function offlineScreen(cfg) {
    var app = document.getElementById('app'); app.textContent = '';
    var box = document.createElement('div'); box.className = 'login';
    var h = document.createElement('h1'); h.textContent = cfg.name; box.appendChild(h);
    var p = document.createElement('p'); p.textContent = 'No hay conexión y todavía no se guardó nada en este aparato. Probá de nuevo cuando vuelva la señal.'; box.appendChild(p);
    app.appendChild(box);
  }
  function showReset(cfg, token) {
    var app = document.getElementById('app'); app.textContent = '';
    var box = document.createElement('form'); box.className = 'login';
    var h = document.createElement('h1'); h.textContent = cfg.name; box.appendChild(h);
    var p = document.createElement('p'); p.className = 'muted'; p.style.margin = '0'; p.textContent = 'Elegí una contraseña nueva (al menos 10 caracteres).'; box.appendChild(p);
    var l = document.createElement('label'); l.textContent = 'Contraseña nueva';
    var i = document.createElement('input'); i.type = 'password'; i.required = true; i.minLength = 10; i.autocomplete = 'new-password'; l.appendChild(i); box.appendChild(l);
    var err = document.createElement('div'); err.className = 'err'; err.setAttribute('role', 'alert'); box.appendChild(err);
    var b = document.createElement('button'); b.className = 'btn pri'; b.type = 'submit'; b.textContent = 'Guardar contraseña'; box.appendChild(b);
    box.addEventListener('submit', function (ev) {
      ev.preventDefault(); b.disabled = true; err.textContent = '';
      fetch('/api/reset', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: token, password: i.value }) })
        .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || 'No se pudo cambiar'); history.replaceState(null, '', '/'); location.reload(); }); })
        .catch(function (e) { err.textContent = e.message; b.disabled = false; });
    });
    app.appendChild(box); i.focus();
  }
  fetch('/api/config').then(function (r) { return r.json(); }).catch(function () { return { name: 'Portal de entregas' }; }).then(function (cfg) {
    window.APP_CONFIG = cfg; document.title = cfg.name;
    var rt = (location.search.match(/[?&]reset=([a-f0-9]{64})/) || [])[1]; if (rt) { showReset(cfg, rt); return; }
    return fetch('/api/me', { credentials: 'same-origin' }).then(function (r) { if (r.ok) load('/app.js'); else showLogin(cfg); }, function () {
      var had = false; try { had = !!JSON.parse(localStorage.getItem('portal.cache') || '{}')['/api/me']; } catch (_) {}
      if (had) load('/app.js'); else offlineScreen(cfg);
    });
  });
})();
